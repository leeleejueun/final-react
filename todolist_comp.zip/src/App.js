import { useState, useRef, useEffect } from 'react';
import './App.scss';
import List from './component/List';
import Insert from './component/Insert';

function App() {
  const [data,setData] = useState([]),
        [todoNum,setTodoNum] = useState(0),
        elInput = useRef(),
        elItems = useRef([]),
        count = useRef(0);

  const add =(e)=>{
    // input값을 받아와서 data 변수에 넣어주는 일
    e.preventDefault(); //넘어가는것을 방지해주는 역할
    let value = {num : ++count.current, todo: elInput.current.value}
    setData([...data,value])
    elInput.current.value='';
    elInput.current.focus();
  };

  const remove =(n)=>{
    let removeData = data.filter((obj)=>obj.num !== n);
    setData(removeData);
  };

  const state =(e)=>{
    e.target.classList.toggle('active');
    update();
  };
  
  const update = ()=>{
    let count = elItems.current.filter((item)=>item&&item.className!='active').length;
    setTodoNum(count);
  };

  useEffect(update,[data]);
  
  return (
    <div className="App">
      <article>
        <List data={data} state={state} remove={remove} todoNum={todoNum} elItems={elItems}/>
        <Insert add={add} elInput={elInput} />
      </article>
    </div>
  );
}

export default App;
