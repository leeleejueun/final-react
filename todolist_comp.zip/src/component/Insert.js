import React from 'react'
//cimport { useState, useRef, useEffect } from 'react';


const Insert = ({add, elInput}) => {
    
    return (
        <div className='write'>
            <form onSubmit={add}>
                <input ref= {elInput} type="text" name="w" placeholder="할 일을 입력하세요." />
                <input type="submit" value="저장" />
            </form>
        </div>
    )
}

export default Insert