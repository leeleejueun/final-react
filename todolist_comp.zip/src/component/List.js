import React from 'react'
import Item from './Item';
//import { useState, useRef, useEffect } from 'react';


const List = ({data, state, remove,todoNum,elItems}) => {

    return (
        <>
            <h1>todolist</h1>
            <p>할일 {todoNum}개 남음</p>
            <ul className='list'>
                {
                    data && data.map((obj,key)=>{
                    return <Item key={key} obj={obj} state={state} remove={remove} elItems={elItems}/>
                    })
                }
            </ul>
        </>
    )
}

export default List