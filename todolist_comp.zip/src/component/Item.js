import React from 'react'
import { useState, useRef, useEffect } from 'react';


const Item = ({obj, state, remove, elItems}) => {
    return (
        <>
            <li ref={(el)=>elItems.current[obj.num - 1]=el}  onClick={state} key={obj.num}>
                {obj.todo}
                <button onClick={()=>remove(obj.num)}>삭제</button>
            </li>
        </>
    )
}

export default Item 